import 'server-only'

const SHARDS = 64

type DetailRow = [
  number,
  number,
  string,
  string,
  string,
  string,
  string,
  string,
  string,
  number[],
  string,
  string,
]

export type PlayerDetail = {
  height: number
  weight: number
  weakFootUsage: string
  weakFootAccuracy: string
  form: string
  injuryResistance: string
  attackStyle: string
  defenseStyle: string
  aptitudes: Record<string, number>
  stats: number[]
  skills: string[]
  aiStyles: string[]
}

function shardOf(pid: string) {
  let x = 0
  for (const c of pid) x = (x * 31 + c.charCodeAt(0)) % SHARDS
  return x
}

const split = (value: string) => value.split('|').filter(Boolean)

export async function getPlayerDetail(pid: string): Promise<PlayerDetail | null> {
  const shard = shardOf(pid)
  const mod = (await import(`../data/details/${shard}.json`)) as { default: Record<string, DetailRow> }
  const row = mod.default[pid]
  if (!row) return null
  const [height, weight, weakFootUsage, weakFootAccuracy, form, injuryResistance, attackStyle, defenseStyle, apt, stats, skills, ai] = row
  const aptitudes: Record<string, number> = {}
  for (const part of split(apt)) {
    const [pos, val] = part.split('=')
    aptitudes[pos] = Number(val)
  }
  return {
    height,
    weight,
    weakFootUsage,
    weakFootAccuracy,
    form,
    injuryResistance,
    attackStyle,
    defenseStyle,
    aptitudes,
    stats,
    skills: split(skills),
    aiStyles: split(ai),
  }
}
