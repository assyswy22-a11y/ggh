import 'server-only'
import rows from '@/data/players.json'
import type { Player } from '@/lib/players'

type Row = [string, string, number, string, string, string, number, 'L' | 'R']

const players: Player[] = (rows as Row[]).map(([pid, name, ovr, position, nationality, pack, age, foot]) => ({
  pid,
  name,
  ovr,
  position,
  nationality,
  pack,
  age,
  foot,
}))

const normalize = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()

const searchIndex = players.map((p) => normalize(`${p.name} ${p.nationality} ${p.pack}`))
const byPid = new Map(players.map((p) => [p.pid, p]))

export const totalPlayers = players.length

export function getPlayersByPid(pids: string[]) {
  return pids.map((pid) => byPid.get(pid)).filter((p): p is Player => Boolean(p))
}

export function getPlayer(pid: string) {
  return byPid.get(pid) ?? null
}

export function getOtherVersions(player: Player, limit: number) {
  return players.filter((p) => p.name === player.name && p.pid !== player.pid).slice(0, limit)
}

export function getTopRated(limit: number) {
  return players.slice(0, limit)
}

export function getPlayersByPack(pack: string, limit: number) {
  return players.filter((p) => p.pack === pack).slice(0, limit)
}

export function searchPlayers({ query, position, limit }: { query: string; position?: string; limit: number }) {
  const terms = normalize(query).split(/\s+/).filter(Boolean)
  const results: Player[] = []
  for (let i = 0; i < players.length && results.length < limit; i++) {
    const p = players[i]
    if (position && p.position !== position) continue
    if (terms.length && !terms.every((t) => searchIndex[i].includes(t))) continue
    results.push(p)
  }
  return results
}
