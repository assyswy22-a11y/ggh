export const POSITION_TR: Record<string, string> = {
  GK: 'KL',
  CB: 'STP',
  LB: 'SLB',
  RB: 'SGB',
  DMF: 'DOS',
  CMF: 'GO',
  AMF: 'OOS',
  LMF: 'SLK',
  RMF: 'SGK',
  LWF: 'SLA',
  RWF: 'SGA',
  SS: 'GF',
  CF: 'SF',
}

export const positionTr = (pos: string) => POSITION_TR[pos] ?? pos

const PLAYING_STYLE_TR: Record<string, string> = {
  'Goal Poacher': 'Fırsatçı Golcü',
  'Fox in the Box': 'Ceza Sahası Golcüsü',
  'Target Man': 'Hedef Santrfor',
  'Deep-Lying Forward': 'Geride Kalan Forvet',
  'Dummy Runner': 'Aldatıcı Koşucu',
  'Prolific Winger': 'Üretken Kanat',
  'Roaming Flank': 'Gezgin Kanat',
  'Cross Specialist': 'Orta Uzmanı',
  'Classic No. 10': 'Klasik 10 Numara',
  'Creative Playmaker': 'Yaratıcı Oyun Kurucu',
  'Hole Player': 'Boşluk Oyuncusu',
  'Box-to-Box': 'Box-to-Box',
  Orchestrator: 'Orkestra Şefi',
  'Anchor Man': 'Çapa Adam',
  'The Destroyer': 'Yıkıcı',
  'Build Up': 'Oyun Kurucu Stoper',
  'Extra Frontman': 'Ekstra Forvet',
  'Attacking Full-back': 'Hücumcu Bek',
  'Defensive Full-back': 'Savunmacı Bek',
  'Full-back Finisher': 'Bitirici Bek',
  'Attacking GK': 'Hücumcu Kaleci',
  'Defensive GK': 'Savunmacı Kaleci',
  'Sweeper GK': 'Libero Kaleci',
}

export function playingStyleTr(attack: string, defense: string) {
  const style = attack && attack !== 'Basic' ? attack : defense && defense !== 'Basic' ? defense : ''
  return style ? (PLAYING_STYLE_TR[style] ?? style.replace(/[()]/g, '')) : 'Temel'
}

const SKILL_TR: Record<string, string> = {
  'Fighting Spirit': 'Savaşçı Ruh',
  Captaincy: 'Kaptanlık',
  'GK Low Punt': 'KL Alçak Vole',
  'GK High Punt': 'KL Yüksek Vole',
  'GK Penalty Saver': 'KL Penaltı Kurtarıcı',
  'GK Long Throw': 'KL Uzun Atış',
  'GK Directing Defence': 'KL Savunmayı Yönetme',
  'GK Spirit Roar': 'KL Moral Kükremesi',
  'Acrobatic Finishing': 'Akrobatik Bitiricilik',
  'Chop Turn': 'Ani Dönüş',
  'First-time Shot': 'Vole Şut',
  Heading: 'Kafa',
  'Knuckle Shot': 'Knuckle Şut',
  'Long Range Shooting': 'Uzun Mesafe Şut Çekme',
  'Penalty Specialist': 'Penaltı Uzmanı',
  'Scissors Feint': 'Makas Çalımı',
  'Acrobatic Clearance': 'Akrobatik Uzaklaştırma',
  'Cut Behind & Turn': 'Arkadan Kesip Dönme',
  Interception: 'Top Kapma',
  'Low Lofted Pass': 'Hafif Yüksekten Pas',
  'Outside Curler': 'Dış Plaseci',
  'Pinpoint Crossing': 'Nokta Atışı Orta',
  'Track Back': 'Geri Koşu',
  'Sole Control': 'Taban Kontrolü',
  Blocker: 'Engelleyici',
  'Man Marking': 'Adam Adama Markaj',
  'Sliding Tackle': 'Kayarak Müdahale',
  'Flip Flap': 'Flip Flap',
  Gamesmanship: 'Oyunbazlık',
  'Marseille Turn': 'Marsilya Dönüşü',
  'One-touch Pass': 'Tek Pas',
  Sombrero: 'Sombrero',
  'Weighted Pass': 'Dengeli Pas',
  'Chip Shot Control': 'Aşırtma Şut',
  'Dipping Shot': 'Düşen Şut',
  'Double Touch': 'Çift Dokunuş',
  'Long-Range Curler': 'Uzaktan Plase',
  'Through Passing': 'Ara Pası Verme',
  'Aerial Superiority': 'Hava Üstünlüğü',
  'Heel Trick': 'Topuk Numarası',
  Rabona: 'Rabona',
  'Long Throw': 'Uzun Taç Atışı',
  'Scotch Move': 'Scotch Hareketi',
  'Super-sub': 'Süper Yedek',
  'Rising Shot': 'Yükselen Şut',
  'No Look Pass': 'Bakmadan Pas',
  Fortress: 'Kale',
  'Visionary Pass': 'Vizyoner Pas',
  'Edged Crossing': 'Yerine Orta',
  'Phenomenal Finishing': 'Fenomenal Bitiricilik',
  'Blitz Curler': 'Yıldırım Plase',
  'Bullet Header': 'Kurşun Kafa',
  'Momentum Dribbling': 'Momentum Top Sürme',
  'Game-changing Pass': 'Oyunu Değiştiren Pas',
  'Phenomenal Pass': 'Fenomenal Pas',
  'Acceleration Burst': 'Hızlanma Patlaması',
  'Aerial Fort': 'Hava Kalesi',
  'Long-reach Tackle': 'Uzun Erimli Müdahale',
  'Low Screamer': 'Alçak Füze',
  Willpower: 'İrade Gücü',
  'Attack Trigger': 'Atak Tetikleyici',
  'Magnetic Feet': 'Manyetik Ayaklar',
  'Shadow Hunt': 'Gölge Avı',
  'Attacking Surge': 'Hücum Dalgası',
  'Power Tackle': 'Güçlü Müdahale',
  'Snap Strike': 'Ani Vuruş',
  'Tap Trick': 'Dokunuş Numarası',
}

export const skillTr = (skill: string) => SKILL_TR[skill] ?? skill

const AI_TR: Record<string, string> = {
  'Long Ball Expert': 'Uzun Top Uzmanı',
  'Incisive Run': 'Delici Koşu',
  'Long Ranger': 'Uzaktan Şutör',
  'Mazing Run': 'Çılgın Koşu',
  'Speeding Bullet': 'Hızlı Mermi',
  Trickster: 'Hileci',
  'Early Cross': 'Erken Orta',
}

export const aiStyleTr = (style: string) => AI_TR[style] ?? style

const LEVEL_TR: Record<string, string> = {
  'Almost Never': 'Neredeyse Hiç',
  Rarely: 'Nadiren',
  Occasionally: 'Bazen',
  Regularly: 'Düzenli',
  Low: 'Düşük',
  Medium: 'Orta',
  High: 'Yüksek',
  'Very High': 'Çok Yüksek',
  Standard: 'Standart',
  Unwavering: 'Değişmez',
  Inconsistent: 'Tutarsız',
}

export const levelTr = (value: string) => LEVEL_TR[value] ?? value

export function statTone(value: number) {
  if (value >= 90) return 'bg-stat-elite text-background'
  if (value >= 80) return 'bg-stat-great text-background'
  if (value >= 70) return 'bg-stat-good text-background'
  if (value >= 60) return 'bg-stat-ok text-background'
  return 'bg-stat-low text-foreground'
}
