export const PLAYER_CARD_BASE_URL = 'https://efimg.com/efootballhub22/images/player_cards'

export function playerCardUrl(pid: string) {
  return `${PLAYER_CARD_BASE_URL}/${encodeURIComponent(pid)}_l.png`
}

export type Player = {
  pid: string
  name: string
  ovr: number
  position: string
  nationality: string
  pack: string
  age: number
  foot: 'L' | 'R'
}

export type PlayerSection = {
  id: string
  title: string
  players: Player[]
}

export const POSITIONS = ['GK', 'CB', 'LB', 'RB', 'DMF', 'CMF', 'AMF', 'LMF', 'RMF', 'LWF', 'RWF', 'SS', 'CF'] as const
