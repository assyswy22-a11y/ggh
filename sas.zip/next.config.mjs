/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
    remotePatterns: [
      { protocol: 'https', hostname: 'efimg.com', pathname: '/efootballhub22/images/player_cards/**' },
    ],
  },
}

export default nextConfig
