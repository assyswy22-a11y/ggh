import Image from 'next/image'
import { TopBar } from '@/components/efhub/top-bar'
import { TabsNav } from '@/components/efhub/tabs-nav'
import { PlayerRow } from '@/components/efhub/player-row'
import { PlayerSearch } from '@/components/efhub/player-search'
import { getPlayersByPack, getPlayersByPid, getTopRated, totalPlayers } from '@/lib/db'
import type { PlayerSection } from '@/lib/players'

const TRENDING_PIDS = [
  '105899666447703',
  '123236838841410',
  '123236838963522',
  '123236838912052',
  '52871852853061',
  '52880442771767',
]

export default function Page() {
  const sections: PlayerSection[] = [
    { id: 'trend', title: 'Trend Olan', players: getPlayersByPid(TRENDING_PIDS) },
    { id: 'strike-arena', title: 'Strike Arena', players: getPlayersByPack('Strike Arena', 15) },
    { id: 'top', title: 'En Yüksek Reytingler', players: getTopRated(15) },
    { id: 'gracias-leo', title: 'Gracias, Leo!', players: getPlayersByPack('Gracias, Leo!', 15) },
  ].filter((s) => s.players.length > 0)

  return (
    <div className="relative mx-auto min-h-dvh w-full max-w-md overflow-hidden bg-background">
      <Image
        src="/images/stadium-bg.png"
        alt=""
        fill
        priority
        sizes="448px"
        className="pointer-events-none fixed object-cover opacity-80"
      />
      <div className="relative flex flex-col">
        <TopBar />
        <TabsNav />
        <main className="flex flex-col gap-6 pt-6 pb-10">
          {sections.map((section) => (
            <PlayerRow key={section.id} section={section} />
          ))}
          <PlayerSearch total={totalPlayers} />
        </main>
      </div>
    </div>
  )
}
