import { NextResponse, type NextRequest } from 'next/server'
import { searchPlayers } from '@/lib/db'
import { POSITIONS } from '@/lib/players'

export function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams
  const query = (params.get('q') ?? '').slice(0, 80)
  const rawPosition = params.get('pos') ?? ''
  const position = (POSITIONS as readonly string[]).includes(rawPosition) ? rawPosition : undefined
  const limit = Math.min(Math.max(Number(params.get('limit')) || 30, 1), 60)

  return NextResponse.json({ players: searchPlayers({ query, position, limit }) })
}
