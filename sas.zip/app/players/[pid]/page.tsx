import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronLeft } from 'lucide-react'
import { PlayerCard } from '@/components/efhub/player-card'
import { PlayerCardImage } from '@/components/efhub/player-card-image'
import { PositionMap } from '@/components/efhub/player-detail/position-map'
import { InfoList, SectionTitle, StatList, TagList } from '@/components/efhub/player-detail/stat-list'
import { getOtherVersions, getPlayer } from '@/lib/db'
import { getPlayerDetail } from '@/lib/player-details'
import { aiStyleTr, levelTr, playingStyleTr, positionTr, skillTr, statTone } from '@/lib/translations'
import { cn } from '@/lib/utils'

type Props = { params: Promise<{ pid: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { pid } = await params
  const player = getPlayer(pid)
  if (!player) return { title: 'Oyuncu bulunamadı | eFHUB' }
  return {
    title: `${player.name} — ${player.ovr} ${positionTr(player.position)} | eFHUB`,
    description: `${player.name} (${player.pack}) oyuncu özellikleri, becerileri ve mevki yatkınlıkları.`,
  }
}

export default async function PlayerPage({ params }: Props) {
  const { pid } = await params
  const player = getPlayer(pid)
  if (!player) notFound()
  const detail = await getPlayerDetail(pid)
  if (!detail) notFound()

  const s = detail.stats
  const versions = getOtherVersions(player, 20)
  const style = playingStyleTr(detail.attackStyle, detail.defenseStyle)
  const isGk = player.position === 'GK'

  const attack = [
    { label: 'Ofansif Farkındalık', value: s[0] },
    { label: 'Top Kontrolü', value: s[1] },
    { label: 'Top Sürme', value: s[2] },
    { label: 'Sıkı Top Tutma', value: s[3] },
    { label: 'Alçaktan Pas', value: s[4] },
    { label: 'Yüksekten Pas', value: s[5] },
    { label: 'Bitiricilik', value: s[6] },
    { label: 'Kafa', value: s[7] },
    { label: 'Duran Top Kullanma', value: s[8] },
    { label: 'Falso', value: s[9] },
  ]
  const athletic = [
    { label: 'Hız', value: s[19] },
    { label: 'Hızlanma', value: s[20] },
    { label: 'Şut Gücü', value: s[21] },
    { label: 'Zıplama', value: s[22] },
    { label: 'Fiziksel Temas', value: s[23] },
    { label: 'Denge', value: s[24] },
    { label: 'Dayanıklılık', value: s[25] },
  ]
  const defense = [
    { label: 'Defansif Farkındalık', value: s[10] },
    { label: 'Defansif Katılım', value: s[13] },
    { label: 'İkili Mücadele', value: s[11] },
    { label: 'Agresiflik', value: s[12] },
    { label: 'KL Farkındalığı', value: s[14] },
    { label: 'KL Yakalama', value: s[15] },
    { label: 'KL Savuşturma', value: s[17] },
    { label: 'KL Refleksler', value: s[16] },
    { label: 'KL Uzanma', value: s[18] },
  ]

  const bio = [
    { label: 'Boy', value: `${detail.height}cm` },
    { label: 'Kilo', value: `${detail.weight}kg` },
    { label: 'Yaş', value: String(player.age) },
    { label: 'Ayak', value: player.foot === 'L' ? 'Sol' : 'Sağ' },
  ]

  return (
    <div className="mx-auto min-h-dvh w-full max-w-md bg-background">
      <header className="sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-background/90 px-3 py-2.5 backdrop-blur">
        <Link
          href="/"
          aria-label="Geri dön"
          className="flex size-8 items-center justify-center rounded-md text-foreground hover:bg-secondary"
        >
          <ChevronLeft className="size-5" aria-hidden="true" />
        </Link>
        <span className="font-display text-lg font-extrabold italic tracking-tight text-foreground">eFHUB</span>
      </header>

      <main className="flex flex-col gap-6 pb-10">
        <section className="flex flex-col gap-3 bg-gradient-to-b from-secondary/60 to-transparent px-3 pt-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="font-display text-[28px] font-extrabold uppercase leading-none tracking-wide text-foreground text-balance">
                {player.name}
              </h1>
              <p className="mt-1 font-display text-sm font-bold uppercase tracking-wide text-foreground">{style}</p>
              <p className="mt-0.5 truncate text-xs text-muted-foreground">
                {player.nationality} · {player.pack}
              </p>
            </div>
            <div className={cn('flex shrink-0 flex-col items-center rounded-md px-2.5 py-1 font-display', statTone(player.ovr))}>
              <span className="font-rating text-2xl font-normal leading-none tabular-nums">{player.ovr}</span>
              <span className="text-xs font-bold">{positionTr(player.position)}</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-3">
            <div className="relative aspect-[240/340] w-[64%] max-w-64 shrink-0">
              <PlayerCardImage player={player} sizes="256px" priority />
            </div>
            <dl className="flex w-[26%] flex-col gap-2">
              {bio.map((item) => (
                <div key={item.label} className="rounded-md bg-card px-2 py-1.5 text-center">
                  <dt className="text-[11px] text-muted-foreground">{item.label}</dt>
                  <dd className="font-display text-base font-bold leading-tight text-foreground">{item.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <div className="grid grid-cols-2 gap-x-3 gap-y-6 px-3">
          {isGk ? (
            <>
              <StatList title="Kalecilik" stats={defense.slice(4)} />
              <StatList title="Atletizm" stats={athletic} />
              <StatList title="Saldırma" stats={attack} />
              <StatList title="Savunma" stats={defense.slice(0, 4)} />
            </>
          ) : (
            <>
              <StatList stats={attack} />
              <StatList stats={athletic} />
              <StatList title="Savunma" stats={defense} />
            </>
          )}
          <TagList title="Beceriler" items={detail.skills.map(skillTr)} empty="Beceri yok" />
          <TagList title="Com Becerileri" items={detail.aiStyles.map(aiStyleTr)} empty="Com becerisi yok" />
          <InfoList
            title="Diğer İstatistikler"
            items={[
              { label: 'Zayıf Ayak Kullanımı', value: levelTr(detail.weakFootUsage) },
              { label: 'Zayıf Ayak Yeteneği', value: levelTr(detail.weakFootAccuracy) },
              { label: 'Form', value: levelTr(detail.form) },
              { label: 'Sakatlık Hassasiyeti', value: levelTr(detail.injuryResistance) },
            ]}
          />
        </div>

        <section className="flex flex-col gap-2 px-3">
          <h2 className="font-display text-lg font-extrabold uppercase text-foreground">{style}</h2>
          <ul className="flex flex-wrap gap-1" aria-label="Oynayabildiği mevkiler">
            {[player.position, ...Object.keys(detail.aptitudes).filter((p) => p !== player.position && detail.aptitudes[p] >= 2)].map(
              (pos) => (
                <li key={pos} className="rounded-sm bg-stat-low px-1.5 py-0.5 font-display text-xs font-bold text-foreground">
                  {positionTr(pos)}
                </li>
              ),
            )}
          </ul>
          <PositionMap main={player.position} aptitudes={detail.aptitudes} />
        </section>

        {versions.length > 0 && (
          <section aria-labelledby="versions" className="flex flex-col gap-3">
            <div className="px-4">
              <h2 id="versions" className="border-l-4 border-primary pl-2 font-display text-xl font-extrabold text-foreground">
                {player.name} için Diğer Versiyonlar
              </h2>
              <p className="pl-3 text-xs text-muted-foreground">{versions.length} versiyon</p>
            </div>
            <ul className="no-scrollbar flex snap-x scroll-px-4 gap-2 overflow-x-auto px-4 pb-1">
              {versions.map((v) => (
                <li key={v.pid} className="w-[28%] shrink-0 snap-start">
                  <PlayerCard player={v} />
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>
    </div>
  )
}
