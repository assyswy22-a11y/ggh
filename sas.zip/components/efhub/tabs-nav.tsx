'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'

const tabs = ['ANA SAYFA', 'OYUNCULAR', 'AKIŞ', 'TOPLULUK']

export function TabsNav() {
  const [active, setActive] = useState('OYUNCULAR')

  return (
    <nav aria-label="Bölümler" className="px-4">
      <div className="no-scrollbar flex gap-8 overflow-x-auto border-b border-border px-2">
        {tabs.map((tab) => {
          const isActive = tab === active
          return (
            <button
              key={tab}
              type="button"
              aria-current={isActive ? 'page' : undefined}
              ref={(el) => {
                if (isActive && el) el.scrollIntoView({ inline: 'center', block: 'nearest' })
              }}
              onClick={() => setActive(tab)}
              className={cn(
                'relative shrink-0 pt-3 pb-4 font-display text-2xl font-bold tracking-wide transition-colors',
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {tab}
              <span
                aria-hidden="true"
                className={cn(
                  'absolute inset-x-0 bottom-2 h-1 rounded-full bg-primary transition-opacity',
                  isActive ? 'opacity-100' : 'opacity-0',
                )}
              />
            </button>
          )
        })}
      </div>
    </nav>
  )
}
