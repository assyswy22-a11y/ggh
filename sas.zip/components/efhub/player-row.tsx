import type { PlayerSection } from '@/lib/players'
import { PlayerCard } from './player-card'

export function PlayerRow({ section }: { section: PlayerSection }) {
  const headingId = `section-${section.id}`
  return (
    <section aria-labelledby={headingId} className="flex flex-col gap-3">
      <h2
        id={headingId}
        className="mx-4 w-fit rounded-full border border-border bg-secondary/70 px-4 py-1.5 text-base font-semibold text-foreground backdrop-blur-sm"
      >
        {section.title}
      </h2>
      <ul className="no-scrollbar flex snap-x scroll-px-4 gap-2 overflow-x-auto px-4 pb-1">
        {section.players.map((player) => (
          <li key={player.pid} className="w-[28%] shrink-0 snap-start">
            <PlayerCard player={player} />
          </li>
        ))}
      </ul>
    </section>
  )
}
