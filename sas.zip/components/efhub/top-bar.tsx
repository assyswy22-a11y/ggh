import { Bell, Menu, Search } from 'lucide-react'

const iconButton =
  'flex size-11 items-center justify-center rounded-full text-foreground transition-colors hover:bg-foreground/10 focus-visible:outline-2 focus-visible:outline-primary'

export function TopBar() {
  return (
    <header className="flex items-center justify-between px-4 pt-6 pb-2">
      <div className="flex items-center gap-1">
        <button type="button" aria-label="Menüyü aç" className={iconButton}>
          <Menu className="size-7" strokeWidth={2.5} />
        </button>
        <button type="button" aria-label="Ara" className={iconButton}>
          <Search className="size-6" strokeWidth={2.75} />
        </button>
        <button type="button" aria-label="Bildirimler" className={iconButton}>
          <Bell className="size-6" strokeWidth={2.25} />
        </button>
      </div>
      <h1 className="font-sans text-4xl font-black tracking-wider text-foreground">eFHUB</h1>
    </header>
  )
}
