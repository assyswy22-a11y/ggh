import { positionTr } from '@/lib/translations'
import { cn } from '@/lib/utils'

const COLUMNS = [
  ['LWF', 'LMF', 'LB'],
  ['CF', 'SS', 'AMF', 'CMF', 'DMF', 'CB', 'GK'],
  ['RWF', 'RMF', 'RB'],
]

export function PositionMap({ main, aptitudes }: { main: string; aptitudes: Record<string, number> }) {
  const levelOf = (pos: string) => (pos === main ? 3 : (aptitudes[pos] ?? 0))

  return (
    <div className="flex flex-col gap-2">
      <div className="grid grid-cols-3 gap-1.5 rounded-lg border border-border bg-[oklch(0.24_0.05_150)] p-2">
        {COLUMNS.map((column, i) => (
          <ul key={i} className="flex flex-col justify-between gap-1.5">
            {column.map((pos) => {
              const level = levelOf(pos)
              return (
                <li
                  key={pos}
                  className={cn(
                    'flex flex-1 items-center justify-center rounded-md py-2 font-display text-sm font-bold',
                    level === 3 && 'bg-primary text-primary-foreground',
                    level === 2 && 'bg-stat-great/70 text-background',
                    level === 1 && 'bg-stat-great/30 text-foreground',
                    level === 0 && 'bg-background/40 text-muted-foreground',
                  )}
                >
                  {positionTr(pos)}
                </li>
              )
            })}
          </ul>
        ))}
      </div>
      <ul className="flex flex-wrap gap-3 text-[11px] text-muted-foreground">
        <li className="flex items-center gap-1">
          <span className="size-2.5 rounded-sm bg-primary" aria-hidden="true" /> Ana mevki
        </li>
        <li className="flex items-center gap-1">
          <span className="size-2.5 rounded-sm bg-stat-great/70" aria-hidden="true" /> Yüksek yatkınlık
        </li>
        <li className="flex items-center gap-1">
          <span className="size-2.5 rounded-sm bg-stat-great/30" aria-hidden="true" /> Orta yatkınlık
        </li>
      </ul>
    </div>
  )
}
