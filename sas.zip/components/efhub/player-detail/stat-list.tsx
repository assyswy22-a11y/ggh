import { statTone } from '@/lib/translations'
import { cn } from '@/lib/utils'

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-2 font-display text-xs font-bold uppercase tracking-wider text-muted-foreground">{children}</h2>
  )
}

export function StatList({ title, stats }: { title?: string; stats: { label: string; value: number }[] }) {
  return (
    <section aria-label={title ?? 'Özellikler'}>
      {title && <SectionTitle>{title}</SectionTitle>}
      <dl className="flex flex-col gap-1">
        {stats.map((stat) => (
          <div key={stat.label} className="flex items-center justify-between gap-2">
            <dt className={cn('truncate text-[13px] font-medium', stat.value < 60 ? 'text-stat-low' : 'text-stat-great')}>
              {stat.label}
            </dt>
            <dd
              className={cn(
                'w-8 shrink-0 rounded-sm py-0.5 text-center font-display text-sm font-bold tabular-nums',
                statTone(stat.value),
              )}
            >
              {stat.value}
            </dd>
          </div>
        ))}
      </dl>
    </section>
  )
}

export function InfoList({ title, items }: { title: string; items: { label: string; value: string }[] }) {
  return (
    <section>
      <SectionTitle>{title}</SectionTitle>
      <dl className="flex flex-col gap-1.5">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between gap-2 text-[13px]">
            <dt className="truncate text-muted-foreground">{item.label}</dt>
            <dd className="shrink-0 font-semibold text-foreground">{item.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  )
}

export function TagList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <section>
      <SectionTitle>{title}</SectionTitle>
      {items.length > 0 ? (
        <ul className="flex flex-col gap-1.5">
          {items.map((item) => (
            <li key={item} className="text-[13px] font-medium text-foreground">
              {item}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-[13px] text-muted-foreground">{empty}</p>
      )}
    </section>
  )
}
