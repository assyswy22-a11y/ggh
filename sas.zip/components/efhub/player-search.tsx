'use client'

import { useDeferredValue, useState } from 'react'
import useSWR from 'swr'
import { Search } from 'lucide-react'
import { POSITIONS, type Player } from '@/lib/players'
import { cn } from '@/lib/utils'
import { PlayerCard } from './player-card'

const fetcher = (url: string) => fetch(url).then((r) => r.json() as Promise<{ players: Player[] }>)

export function PlayerSearch({ total }: { total: number }) {
  const [query, setQuery] = useState('')
  const [position, setPosition] = useState('')
  const deferredQuery = useDeferredValue(query.trim())

  const params = new URLSearchParams({ q: deferredQuery, pos: position, limit: '30' })
  const { data, isLoading } = useSWR(`/api/players?${params}`, fetcher, { keepPreviousData: true })
  const players = data?.players ?? []

  return (
    <section aria-labelledby="section-database" className="flex flex-col gap-3 px-4">
      <div className="flex items-baseline justify-between gap-2">
        <h2
          id="section-database"
          className="w-fit rounded-full border border-border bg-secondary/70 px-4 py-1.5 text-base font-semibold text-foreground backdrop-blur-sm"
        >
          Oyuncu Veritabanı
        </h2>
        <span className="text-xs text-muted-foreground">{total.toLocaleString('tr-TR')} oyuncu</span>
      </div>

      <label className="flex items-center gap-2 rounded-lg border border-border bg-secondary/70 px-3 py-2 backdrop-blur-sm focus-within:border-primary">
        <Search className="size-4 text-muted-foreground" aria-hidden="true" />
        <span className="sr-only">Oyuncu ara</span>
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Oyuncu, ülke veya paket ara…"
          className="w-full bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
      </label>

      <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4" role="group" aria-label="Pozisyon filtresi">
        {['', ...POSITIONS].map((pos) => (
          <button
            key={pos || 'all'}
            type="button"
            aria-pressed={position === pos}
            onClick={() => setPosition(pos)}
            className={cn(
              'shrink-0 rounded-full border px-3 py-1 text-xs font-semibold transition-colors',
              position === pos
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-secondary/70 text-muted-foreground hover:text-foreground',
            )}
          >
            {pos || 'Tümü'}
          </button>
        ))}
      </div>

      {players.length > 0 ? (
        <ul className={cn('grid grid-cols-3 gap-2 transition-opacity', isLoading && 'opacity-60')}>
          {players.map((player) => (
            <li key={player.pid}>
              <PlayerCard player={player} />
            </li>
          ))}
        </ul>
      ) : (
        <p className="py-8 text-center text-sm text-muted-foreground" aria-live="polite">
          {isLoading ? 'Yükleniyor…' : 'Oyuncu bulunamadı.'}
        </p>
      )}
    </section>
  )
}
