'use client'

import Image from 'next/image'
import { useState } from 'react'
import { playerCardUrl, type Player } from '@/lib/players'
import { positionTr } from '@/lib/translations'

const outlined = {
  WebkitTextStroke: '0.09em #000',
  paintOrder: 'stroke fill',
  textShadow: '0 0.04em 0.06em rgb(0 0 0 / 0.6)',
} as const

export function PlayerCardImage({
  player,
  sizes = '(max-width: 448px) 30vw, 136px',
  priority = false,
}: {
  player: Player
  sizes?: string
  priority?: boolean
}) {
  const [failed, setFailed] = useState(false)

  if (failed) {
    return (
      <div className="flex size-full flex-col justify-between rounded-md border border-border bg-card p-1.5 font-display text-foreground">
        <span className="flex flex-col leading-none">
          <span className="font-rating text-2xl font-normal">{player.ovr}</span>
          <span className="text-xs font-bold text-primary">{positionTr(player.position)}</span>
        </span>
        <span className="truncate text-center text-xs font-bold">{player.name}</span>
      </div>
    )
  }

  return (
    <span className="@container absolute inset-0 block">
      <Image
        src={playerCardUrl(player.pid) || '/placeholder.svg'}
        alt=""
        fill
        sizes={sizes}
        priority={priority}
        onError={() => setFailed(true)}
        className="object-contain drop-shadow-lg"
      />
      <span
        aria-hidden="true"
        className="pointer-events-none absolute top-[1.5cqw] left-[4cqw] flex flex-col items-center font-display font-black leading-none text-white"
      >
        <span className="font-rating text-[25cqw] font-normal tabular-nums" style={outlined}>
          {player.ovr}
        </span>
        <span className="-mt-[0.5cqw] text-[12cqw] font-extrabold" style={outlined}>
          {positionTr(player.position)}
        </span>
      </span>
    </span>
  )
}
