import Link from 'next/link'
import { PlayerCardImage } from '@/components/efhub/player-card-image'
import type { Player } from '@/lib/players'
import { positionTr } from '@/lib/translations'

export function PlayerCard({ player }: { player: Player }) {
  return (
    <Link
      href={`/players/${player.pid}`}
      aria-label={`${player.name}, ${player.ovr} genel, ${positionTr(player.position)}${player.pack ? `, ${player.pack}` : ''}`}
      title={player.pack ? `${player.name} — ${player.pack}` : player.name}
      className="group block rounded-md transition-transform hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-primary"
    >
      <span className="relative block aspect-[240/340] w-full">
        <PlayerCardImage player={player} />
      </span>
    </Link>
  )
}
